## redux 不一样的源码解析(非常非常的详细)

## 本文将和你一起来一步一步的分析redux的源码

目前网上有很多关于redux源码的解析文章， 但是都是直接给出源码的解读， 本文将以不一样的方式和你一起来一步一步研究redux的源码

先自卖自夸一下，个人觉得是最全最细最啰嗦的redux解析

直接看scr/redux/index.js文件夹， 里面注释很清楚

## react-redux源码解析


直接看scr/react-redux/index.js文件夹， 里面注释同样很清楚哦
